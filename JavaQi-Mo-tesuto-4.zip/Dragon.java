public class Dragon extends Character implements FlyingCreature {
  private boolean flying;

  public Dragon() {
    setName("火龍");
    setHp(150);
    setFlying(true);
  }
  
  public void setFlying(boolean flying) {
    this.flying = flying;
  }

  public boolean getFlying() {
    return flying;
  }

  public void attack(Character c) {
    int damage;
    if(getFlying()) {
      damage = 25;
      System.out.println(getName() + "は、空から押しつぶした！");
      System.out.println(c.getName() + "に" + damage + "ダメージ！");
      c.subtractHp(damage);
    } else {
      damage = 15;
      System.out.println(getName() + "は、かみついた！");
      System.out.println(c.getName() + "に" + damage + "ダメージ！");
      c.subtractHp(damage);
    }
  }
  public void fly() {
    if(getFlying()) { return; }
    setFlying(true);
    System.out.println(getName() + "は、大空へ羽ばたいた！");
  }
  public void land() {
    if(!getFlying()) { return; }
    setFlying(false);
    System.out.println(getName() + "は、地上に降りた！");
  }
  public void doRandomAction() {
    int rand = (int)(Math.random() * 5);
    switch(rand) {
      case 0:
      case 1:
      case 2:
      case 3:
        attack(getTarget());
        break;
      case 4:
        if(getFlying()) { land(); }
        else { fly(); }
      default:
    }
  }
}
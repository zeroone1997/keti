public abstract class Character {
  private String name;
  private int hp;
  private Character target;
  
  public void setName(String name){
    this.name = name;
  }
  
  public String getName(){
    return this.name;
  }
  
  public void setHp(int hp){
    this.hp = hp;
  }
  
  public int getHp(){
    return this.hp;
  }

  public void setTarget(Character c) {
    this.target = c;
  }

  public Character getTarget() {
    return this.target;
  }
  
  public boolean isDead() {
    if(getHp() < 1) { return true; }
    else { return false; }
  }
  
  public void subtractHp(int damage) {
    setHp(getHp() - damage);
  }

  public abstract void attack(Character c);
  
}

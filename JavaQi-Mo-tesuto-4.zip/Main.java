public class Main {
  public static void main(String[] args) {
    int command; 
    java.util.Scanner scan = new java.util.Scanner(System.in);  
    
    Hero player = new Hero("堀");
    Dragon com = new Dragon();

    player.setTarget(com);
    com.setTarget(player);

    while(!(player.isDead() || com.isDead())) {
      player.showCommand();
      do {
        command = scan.nextInt();
        try{
          player.doCommand(command);
          break;
        }catch(Exception e){
          continue;
        }
      } while(true);

      System.out.println();

      com.doRandomAction();

      System.out.println();
    }

    checkResult(player, com);
  }
  
  public static void checkResult(Hero player, Dragon com) {
    if(player.isDead()) {
      System.out.println("ざんねん！あなたの負けです...");
    } else if(com.isDead()) {
      System.out.println("おみごと！敵を倒しました！");
    } else {
      System.out.println("戦いはまだまだ続きます。");
    }
  }

  public static void gameEnd() {
    System.out.println("ゲームを終了します。");
    System.exit(0);
  }
}

public interface FlyingCreature {
  void fly();
  void land();
}
public class Hero extends Character {
  
  private Weapon weapon;  //装備している武器
  private final static String[] commands = {"攻撃する", "装備を変える", "スペシャルアタック"};  //操作できるコマンド
  private final static Weapon[] weapons = { //装備できる武器
    new Sword("ナイフ", 5),
    new Sword("ブロードソード", 10),
    new Sword("炎のつるぎ", 15),
    new Bow("龙骨の弓", 25),
  };
  private int mp;
  
  public void setMp(int mp){
    this.mp = mp;
    if(this.mp < 1){this.mp = 0;}
  }
  
  public int getMp(){
    return this.mp;
  }

  public Hero(String name) {
    setName(name);
    setMp(100);
    setHp(100);
  }
  
  public void setWeapon(Weapon w) {
    this.weapon = w;
  }

  public Weapon getWeapon() {
    return this.weapon;
  }

  public void attack(Character c) {
    Weapon w = getWeapon();
    Weapon b = getWeapon();
    int damage;

    if(w instanceof Sword) {
      damage = w.getDamage();
      System.out.println(getName() + "は、切りつけた！");
      System.out.println(c.getName() + "に" + damage + "ダメージ！");
      c.subtractHp(damage);
    }
    else if(b instanceof Bow){
      damage = w.getDamage();
      System.out.println(getName() + "は、矢を放った！");
      System.out.println(c.getName() + "に" + damage + "ダメージ！");
      c.subtractHp(damage);
    }
    else {
      damage = 3;
      System.out.println(getName() + "の攻撃！");
      System.out.println(c.getName() + "に" + damage + "ダメージ！");
      c.subtractHp(damage);
    }
  }

  public void showCommand() {
    for(int i = 0; i < this.commands.length; i++) {
      System.out.print("[" + i + "]" + this.commands[i] + "\t");
    }
    System.out.println("[" + this.commands.length + "]ゲーム終了");
  }

  public void doCommand(int command) throws Exception {
    if(command < 0 || command > this.commands.length) { 
      throw new Exception("入力エラー");
    }
    
    switch(command) {
      case 0:
        attack(getTarget());
        break;

      case 1:
        Weapon w = createRandomWeapon();
        setWeapon(w);
        System.out.println(getName() + "は、" + w.getName() + "を装備した。");
        break;

      case 2:
        if(getWeapon() == null) {
          System.out.println("しかし、武器を装備していなかった。");
          throw new Exception("武器装備エラー");
        } else {
          System.out.println(getName() + "のスペシャルアタック！");
          getWeapon().specialAttack(getTarget());
        }
        break;
      default:
        Main.gameEnd();
        break;
    }

    return;
  }

  public Weapon createRandomWeapon() {
    int rand = (int)(Math.random() * this.weapons.length);
    return this.weapons[rand];
  }
}
public class Bow extends Weapon {
  public Bow(String name, int damage) {
    super(name, damage);
  }

  public void specialAttack(Character c) {
    double rand = Math.random();
    int damage;
    if(rand < 0.5) {
      damage = getDamage() * 2;
      System.out.println("矢を放った、" + c.getName() + "に" + damage + "ダメージ！");
      c.subtractHp(damage);
    }
    else {
      System.out.println("しかし、失敗した。");
    }
  }
}